Thanks To the original author for the his addon which this new addon is based on.
Original Addon = Dramaonline; Original Author : Aresu