#!/usr/bin/python
# (c)2uk3y, December 21, 2015
# Greetz to: TioEuy & Bosen
# Version:
# 20151221: 1.0: First release
# Addon is based on Dramaonline Addon authored by Aresu.
# License GPL Version 2

import xbmc,xbmcplugin
import xbmcgui
import sys
import urllib, urllib2
import time
import re
from htmlentitydefs import name2codepoint as n2cp
import httplib
import urlparse
from os import path, system
import socket
from urllib2 import Request, URLError, urlopen
from urlparse import parse_qs
from urllib import unquote_plus
import xbmcaddon
import json
from bs4 import BeautifulSoup
from resources.lib import jsunpack
from resources.lib import client

pass#print  "Here in default-py sys.argv =", sys.argv

mainURL="http://www.zoptv.com"
thisPlugin = int(sys.argv[1])
addonId = "plugin.video.zoptv"
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
addon = xbmcaddon.Addon()
path = addon.getAddonInfo('path')
pic = path+"/icon.png"
picNext = path+"/next.png"
picFanart = path+"/fanart.jpg"
progress = xbmcgui.DialogProgress()

#if not path.exists(dataPath):
#       cmd = "mkdir -p " + dataPath
#       system(cmd)
     
Host = "http://www.zoptv.com"

def getUrl(url, referer=''):
    req = urllib2.Request(url)
    # req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    req.add_header('User-Agent','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:43.0) Gecko/20100101 Firefox/43.0')
    if referer:
      req.add_header('Referer', referer)
      req.add_header('Connection', 'keep-alive')
      req.add_header('Access-Control-Allow-Origin', '*')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    
def playVideo(url):
    player = xbmc.Player()
    player.play(url)

def gedebug(strTxt):
    print '##################################################################################################'
    print '### GEDEBUG: ' + str(strTxt)
    print '##################################################################################################'
    return
    
def addSearch():
    searchStr = ''
    keyboard = xbmc.Keyboard(searchStr, 'Search')
    keyboard.doModal()
    if (keyboard.isConfirmed()==False):
      return
    searchStr=keyboard.getText()
    if len(searchStr) == 0:
      return
    else:
      return searchStr 

def showSearch():
    stext = addSearch()
    name = stext
    try:
      url = "/channels/" + stext.replace(' ','%20')
      ok = showChannels(url)
    except:
      pass

def showMainMenu():
    addDirectoryItem("Featured Channels", {"name":"Featured Channels", "url":Host, "mode":4}, pic)
    addDirectoryItem("Browse by Country", {"name":"Browse by Country", "url":Host, "mode":1, "by":"country"}, pic)
    addDirectoryItem("Browse by Genre", {"name":"Browse by Genre", "url":Host, "mode":1, "by":"genre"}, pic) 
    addDirectoryItem("Search", {"name":"Search", "url":Host, "mode":99}, pic)   

    xbmcplugin.endOfDirectory(thisPlugin)

def showFeatured():
    content = getUrl(mainURL)
    # gedebug(content)
    soup = BeautifulSoup(content)

    channels = soup.find('div','fc-by-country').find_all('a','zp-channel')
    # gedebug(fc)
    for channel in channels:
      country = channel.parent('div','title')[0].find('a').get_text()
      # gedebug(country)
      link = channel['href']
      pic = channel.img['src']
      pic = mainURL+pic
      title = channel.span.get_text()
      title = title+'  |  '+country

      addDirectoryItem(title, {"name":title, "url":link, "mode":3}, pic)

    xbmcplugin.endOfDirectory(thisPlugin)

def showSubMenu(by):
    content = getUrl(mainURL)
    # gedebug(content)
    soup = BeautifulSoup(content)
    # gedebug(soup)

    countries = soup.find('div','channels-menu').find_all('ul')[0].find_all('li')
    genres = soup.find('div','channels-menu').find_all('ul')[1].find_all('li')
    # gedebug(countries)

    if by == 'country':
      for country in countries:
        try:
          link = country.a['href']
          title = country.get_text()
          addDirectoryItem(title, {"name":title, "url":link, "mode":2}, pic)
        except:
          pass
    elif by == 'genre':
      for genre in genres:
        try:
          link = genre.a['href']
          title = genre.get_text()
          addDirectoryItem(title, {"name":title, "url":link, "mode":2}, pic)
        except:
          pass

    xbmcplugin.endOfDirectory(thisPlugin)

def showChannels(url):
    content = getUrl(mainURL+url)
    soup = BeautifulSoup(content)
    # gedebug(soup)
    found = soup.find('div','zp-channel-list').find_all('a')
    # gedebug(found)
    for find in found:
      link = find['href']
      pic = find.img['src']
      pic = mainURL+pic
      title = find.span.get_text()
      
      addDirectoryItem(title, {"name":title, "url":link, "mode":3}, pic)

    xbmcplugin.endOfDirectory(thisPlugin)


def getSource(url):
    referer = mainURL+url
    content = getUrl(referer)
    # gedebug(content)

    result = re.compile('eval\(decodeURIComponent\(atob\(\'(.*?)\'\)\)\)').findall(content)[-1]
    result = result.decode('base64','strict')
    result = re.compile('eval\(decodeURIComponent\(atob\(\'(.*?)\'\)\)\)').findall(result)[-1]
    result = result.decode('base64','strict')
    result = re.compile('eval\(decodeURIComponent\(atob\(\'(.*?)\'\)\)\)').findall(result)[-1]
    result = result.decode('base64','strict')
    result = re.compile('eval\(decodeURIComponent\(atob\(\'(.*?)\'\)\)\)').findall(result)[-1]
    result = result.decode('base64','strict')
    result = re.compile('eval\(decodeURIComponent\(atob\(\'(.*?)\'\)\)\)').findall(result)[-1]
    result = result.decode('base64','strict')
    result = re.compile('eval\(decodeURIComponent\(atob\(\'(.*?)\'\)\)\)').findall(result)[-1]
    result = result.decode('base64','strict')
    result = re.compile('eval\(decodeURIComponent\(atob\(\'(.*?)\'\)\)\)').findall(result)[-1]
    result = result.decode('base64','strict')
    result = re.compile('eval\(decodeURIComponent\(atob\(\'(.*?)\'\)\)\)').findall(result)[-1]
    result = result.decode('base64','strict')   
    # gedebug(result)

    src = re.compile('"src":"(.*?)"').findall(result)[0]
    
    content = getUrl(src, referer)
    # gedebug(content)
    link = re.compile('src = \'(.*?)\'').findall(content)[-1]
    
    if not re.compile('(http)').findall(link):
      link = 'http://www.iptvlinks.tk'+link

    gedebug(link)
    playVideo(link)

def updateProgressBar(i, l, intl):
    percent = int( ( i / float(intl) ) * 100)
    message = "Found : " + str(i) + " out of "+str(l)
    progress.update( percent, "", message, "" )
    # print "Message " + str(i) + " out of 10"
    # xbmc.sleep( 1000 )

std_headers = {
	'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
	'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'en-us,en;q=0.5',
}  

def addDirectoryItem(name, parameters={},pic=""):
    li = xbmcgui.ListItem(name,iconImage="", thumbnailImage=pic)
    li.setInfo( "video", { "Title" : name, "FileName" : name} )
    # if pic == path+"/icon.png" or pic == path+"/next.png": pic = picFanart
    li.setProperty('Fanart_Image', picFanart)
    # gedebug(urllib.urlencode(parameters))
    url = sys.argv[0] + '?' + urllib.urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)


def parameters_string_to_dict(parameters):
    ''' Convert parameters encoded in a URL to a dict. '''
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict

params = parameters_string_to_dict(sys.argv[2])
name =  str(params.get("name", ""))
url =  str(params.get("url", ""))
url = urllib.unquote(url)
mode =  str(params.get("mode", ""))
by = str(params.get("by", ""))

#### ACTIONS ####
if not sys.argv[2]:
    pass#print  "Here in default-py going in showContent"
    ok = showMainMenu()
else:
    if mode == str(1):
        ok = showSubMenu(by)
    elif mode == str(2):
        ok = showChannels(url)
    elif mode == str(3):
        ok = getSource(url)
    elif mode == str(4):
        ok = showFeatured()
    elif mode == str(99):  #Click Search
        ok = showSearch()
