import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.AresMafia'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = "PLMm4_hbBHoPuo727gvbQt9zbaDnpLIomg"
YOUTUBE_CHANNEL_ID_2 = "PLJJIBdb0SLsOcDBOzMh4SmEQVV_knyZb0"
YOUTUBE_CHANNEL_ID_3 = "PL_jFbqOSEqaK6ld2CKrGXrVyeKbKvhsqb"
YOUTUBE_CHANNEL_ID_4 = "PL3fXBEkmyMGhUuKlGGzIHzdyHBiDozYJd"
YOUTUBE_CHANNEL_ID_5 = "PL5Nsm2pTwfM2680_M4PP8q4uxWQVN7F6d"
YOUTUBE_CHANNEL_ID_6 = "UCn8zNIfYAQNdrFRrr8oibKw"
YOUTUBE_CHANNEL_ID_7 = "UC6Y8uW7l-tKAaj_sAP5gvIQ"
YOUTUBE_CHANNEL_ID_8 = "PLqkhyODRHpwTbzFhOAVUtay4WRWfMeXCS"
YOUTUBE_CHANNEL_ID_9 = "PL87F7AA03E12095F1"
YOUTUBE_CHANNEL_ID_10 = "PL0rYp3orjJTAOQ1itBEQulNVRSaKrwlPR"
YOUTUBE_CHANNEL_ID_11 = "PLRjIjI3DNXyRIwNSXfceNHGojxPTGpMNC"
YOUTUBE_CHANNEL_ID_12 = "PL_jFbqOSEqaK6ld2CKrGXrVyeKbKvhsqb"
YOUTUBE_CHANNEL_ID_13 = "PLIlFxQf6HAfLNsSgFzAVBwLx91WcPsrcc"
YOUTUBE_CHANNEL_ID_14 = "PLddkRvYo0Uh_wNaK5xGgNcCY1DIOCGPfB"
YOUTUBE_CHANNEL_ID_15 = "PLkd-N2VzpuO2tzDpA6P0ERQEo_YHzJiK3"
YOUTUBE_CHANNEL_ID_16 = "PLQCdRTMW5xux2-d9fxSDhg90SzFXmL1Tm"

# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Mafia Hitmen[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="http://1.bp.blogspot.com/-vTQ4btlMPP8/TgJANvUP_uI/AAAAAAAADpA/ssh_eVlDqus/s1600/LucianoLansky.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="[COLORyellow]Inside The American Mafia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://s-media-cache-ak0.pinimg.com/564x/c2/9d/a6/c29da6f0716b6a4e245f7c716534138e.jpg",
        folder=True )
		
    plugintools.add_item(
        #action="",
        title="[COLORyellow]Gang Documentaries[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="http://www.streetgangs.com/wp-content/uploads/2012/05/maras-fix.jpg",
        folder=True )

    plugintools.add_item(
        #action="",
        title="[COLORyellow]The Sicilian Mafia History of Cosa Nostra Crime Documentary[/COLOR] ",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="http://ak1.ostkcdn.com/images/products/is/images/direct/97fda8238cc148b3981f7d3b649f2fbfadf06e3e/''Mafia-Gangsters''-by-Anon-Movie-%26-TV-Posters-Art-Print.jpg",
        folder=True )
        
    plugintools.add_item(
	    #action="",
        title="[COLORyellow]Crime Documentaries[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="http://www.all-in-one-events.co.za/wp-content/uploads/2015/05/Crime-Scene-Investigation-Games.jpg",
        folder=True )

    plugintools.add_item(
	    #action="",
        title="[COLORyellow]Vice - Full Channel[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail="https://cdn.asiancorrespondent.com/wp-content/uploads/2016/06/Vice-Daily-News-Show-Go90.jpg",
        folder=True )

    plugintools.add_item(
	    #action="",
        title="[COLORyellow]Ross Kemp - Full Channel[/COLOR]",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_7+"/",
        thumbnail="http://digitalspyuk.cdnds.net/14/03/768x605/gallery_uktv-ross-kemp-extreme-world-2.jpg",
        folder=True )

    plugintools.add_item(
	    #action="",
        title="[COLORyellow]Pablo Escobar[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_8+"/",
        thumbnail="https://img1.steemit.com/0x0/http://blogdenoticiasaldia.com/wp-content/uploads/2016/05/PabloEscobar-Millonario.jpg",
        folder=True )

    plugintools.add_item( 
        #action="",
        title="[COLORyellow]The Krays[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_9+"/",
        thumbnail="https://upload.wikimedia.org/wikipedia/sh/8/82/Ronnie-reggie-and-violet-kray1-426x333.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="",
        title="[COLORyellow]Gambino Crime Family[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_10+"/",
        thumbnail="http://i.tmgrup.com.tr/dailysabah/2015/11/23/HaberDetay/1448272553162.jpg",
        folder=True )
    
    plugintools.add_item( 
        #action="",
        title="[COLORyellow]Whitey Bulger[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_11+"/",
        thumbnail="http://s.newsweek.com/sites/www.newsweek.com/files/styles/lg/public/2011/09/11/1337256000000.cached_25.jpg",
        folder=True )	
    
    plugintools.add_item( 
        #action="",
        title="[COLORyellow]Worldwide Mafia[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_12+"/",
        thumbnail="http://www.egaliteetreconciliation.fr/IMG/arton39417.jpg?1463420416",
        folder=True )
	
    plugintools.add_item( 
        #action="",
        title="[COLORyellow]1920s & 1930s Gangsters[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_13+"/",
        thumbnail="http://rosecity-mi.us/wp-content/uploads/2014/01/1936_purple-gang-1936.jpg",
        folder=True )
    
    plugintools.add_item( 
        #action="",
        title="[COLORyellow]Hells Angels Biker Gang[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_14+"/",
        thumbnail="http://montreal.canadanews.ga/polopoly_fs/1.1441357.1378389583!/httpImage/image.jpg_gen/derivatives/landscape_620/image.jpg",
        folder=True )
	
    plugintools.add_item( 
        #action="",
        title="[COLORyellow]Bandidos Biker Gang[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_15+"/",
        thumbnail="http://www.abc.net.au/cm/lb/4999528/data/bandidos-data.jpg",
        folder=True )

    plugintools.add_item( 
        #action="",
        title="[COLORyellow]Mongols Biker Gang[/COLOR]",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_16+"/",
        thumbnail="https://img.rt.com/files/news/40/75/10/00/mongols.jpg",
        folder=True )
     
run() 