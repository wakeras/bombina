#!/usr/bin/python
# (c)2uk3y, December 30, 2015
# Greetz to: TioEuy & Bosen
# Version:
# 20151221: 1.0: First release
# Addon is based on Dramaonline Addon authored by Aresu.
# License GPL Version 2

import xbmc,xbmcplugin
import xbmcgui
import sys
import urllib, urllib2
import time
import re, unicodedata
from htmlentitydefs import name2codepoint as n2cp
import httplib
import urlparse
from os import path, system
import socket
from urllib2 import Request, URLError, urlopen
from urlparse import parse_qs
from urllib import unquote_plus
import xbmcaddon
import json
from bs4 import BeautifulSoup
from resources.lib import jsunpack
from resources.lib import client

pass#print  "Here in default-py sys.argv =", sys.argv

mainURL="http://szeptestben.net"
thisPlugin = int(sys.argv[1])
addonId = "plugin.video.zoptv"
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
addon = xbmcaddon.Addon()
path = addon.getAddonInfo('path')
pic = path+"/icon.png"
picNext = path+"/next.png"
picFanart = path+"/fanart.jpg"
progress = xbmcgui.DialogProgress()

#if not path.exists(dataPath):
#       cmd = "mkdir -p " + dataPath
#       system(cmd)
     
Host = "http://szeptestben.net"

def getUrl(url, referer=''):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    
def playVideo(url):
    player = xbmc.Player()
    player.play(mainURL + url)

def gedebug(strTxt):
    print '##################################################################################################'
    print '### GEDEBUG: ' + str(strTxt)
    print '##################################################################################################'
    return
    
def addSearch():
    searchStr = ''
    keyboard = xbmc.Keyboard(searchStr, 'Search')
    keyboard.doModal()
    if (keyboard.isConfirmed()==False):
      return
    searchStr=keyboard.getText()
    if len(searchStr) == 0:
      return
    else:
      return searchStr 

def showSearch():
    stext = addSearch()
    name = stext
    try:
      url = "/channels/" + stext.replace(' ','%20')
      ok = showChannels(url)
    except:
      pass

def showMainMenu():
    addDirectoryItem("TV Series", {"name":"TV Series", "url":Host, "mode":1}, pic)
    # addDirectoryItem("Browse by Country", {"name":"Browse by Country", "url":Host, "mode":1, "by":"country"}, pic)
    # addDirectoryItem("Browse by Genre", {"name":"Browse by Genre", "url":Host, "mode":1, "by":"genre"}, pic) 
    # addDirectoryItem("Search", {"name":"Search", "url":Host, "mode":99}, pic)   

    xbmcplugin.endOfDirectory(thisPlugin)

def showLetterList(url):
    alpha='#abcdefghijklmnopqrstuvwxyz'
    for i in range(len(alpha)):
      if alpha[i] == '#': huruf = '0-9'
      else: huruf = alpha[i].upper()
      # huruf = alpha[i].upper()
      addDirectoryItem(alpha[i].upper(), {"name":huruf, "url":url, "mode":2, "letter":huruf}, pic)
    xbmcplugin.endOfDirectory(thisPlugin)

def showTitle(url, letter):
    url = url + '/Series/' + letter

    # gedebug(url)
    content = getUrl(url)
    soup = BeautifulSoup(content)
    epNames = soup.find_all('a')
    i = 0
    for epName in epNames:
      if i != 0:
        title = epName.get_text()
        title = title.replace(u'\u2019',u'\'')
        link = epName['href']
        # gedebug(link)
        pic = path+"/icon.png"
        fanart = path+"/fanart.jpg"
        # get metadata
        # https://www.themoviedb.org/search/remote/multi?query=assassin%27s%20creed&language=en
        # https://image.tmdb.org/t/p/w185/hwiOIUGoigpqwpcpwc.jpg
        # https://image.tmdb.org/t/p/w780/cVWsigSx97cTw1QfYFFsCMcR4bp.jpg
        q = title.replace(u'\'',u'%27')
        q = title.replace(u' ',u'%20')
        jsonURL = 'https://www.themoviedb.org/search/remote/multi?query='+q+'&language=en'
        content = getUrl(jsonURL)
        datas = json.loads(content)
        for data in datas:

          if data['media_type'] == 'tv' and data['poster_path']:
            # gedebug(title)
            pic = 'https://image.tmdb.org/t/p/w185'+data['poster_path']
            fanart = 'https://image.tmdb.org/t/p/w780'+data['backdrop_path']
            # gedebug(fanart)
            break

        addDirectoryItem(title, {"name":title, "url":link, "mode":3, 'thumbnail':pic, 'fanart':fanart}, pic, fanart)
      i = i+1

    xbmcplugin.endOfDirectory(thisPlugin)

def showSeason(name, url, pic, fanart):
    content = getUrl(mainURL+url)
    soup = BeautifulSoup(content)
    epNames = soup.find_all('a')
    # gedebug(epNames)
    i = 0
    for epName in epNames:
      if i != 0:
        title = epName.get_text()
        title = title.replace(u'\u2019',u'\'')
        # title = name + ' - ' + title
        link = epName['href']

        try:
          match = re.compile('.mkv').findall(title)[0]
          mode = 69
        except:
          mode = 4


        addDirectoryItem(title, {"name":title, "url":link, "mode":mode, 'thumbnail':pic, 'fanart':fanart}, pic, fanart)
      i = i+1

    xbmcplugin.endOfDirectory(thisPlugin)


def showQuality(name, url, pic, fanart):
    content = getUrl(mainURL+url)
    soup = BeautifulSoup(content)
    epNames = soup.find_all('a')
    i = 0
    for epName in epNames:
      if i != 0:
        title = epName.get_text()
        # title = name + ' - ' + title
        link = epName['href']

        try:
          match = re.compile('.mkv').findall(title)[0]
          mode = 69
        except:
          mode = 5

        addDirectoryItem(title, {"name":title, "url":link, "mode":mode, 'thumbnail':pic, 'fanart':fanart}, pic, fanart)
      i = i+1

    xbmcplugin.endOfDirectory(thisPlugin)


def showVideoList(name, url, pic, fanart):
    content = getUrl(mainURL+url)
    soup = BeautifulSoup(content)
    epNames = soup.find_all('a')
    i = 0
    for epName in epNames:
      if i != 0:
        title = epName.get_text()
        # title = name + ' - ' + title
        link = epName['href']
        addDirectoryItem(title, {"name":title, "url":link, "mode":69, 'thumbnail':pic, 'fanart':fanart}, pic, fanart)
      i = i+1

    xbmcplugin.endOfDirectory(thisPlugin)

    

def updateProgressBar(i, l, intl):
    percent = int( ( i / float(intl) ) * 100)
    message = "Found : " + str(i) + " out of "+str(l)
    progress.update( percent, "", message, "" )
    # print "Message " + str(i) + " out of 10"
    # xbmc.sleep( 1000 )

std_headers = {
	'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
	'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'en-us,en;q=0.5',
}  

def addDirectoryItem(name, parameters={},pic="",fanart=""):
    li = xbmcgui.ListItem(name,iconImage="", thumbnailImage=pic)
    li.setInfo( "video", { "Title" : name, "FileName" : name} )
    # if pic == path+"/icon.png" or pic == path+"/next.png": pic = picFanart
    if not fanart:
      fanart = picFanart
    li.setProperty('Fanart_Image', fanart)
    # gedebug(urllib.urlencode(parameters))
    url = sys.argv[0] + '?' + urllib.urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)


def parameters_string_to_dict(parameters):
    ''' Convert parameters encoded in a URL to a dict. '''
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict

params = parameters_string_to_dict(sys.argv[2])
name =  str(params.get("name", ""))
url =  str(params.get("url", ""))
url = urllib.unquote(url)
mode =  str(params.get("mode", ""))
letter = str(params.get("letter", ""))
thumbnail = str(params.get("thumbnail", ""))
fanart = str(params.get("fanart", ""))
thumbnail = urllib.unquote(thumbnail)
fanart = urllib.unquote(fanart)

#### ACTIONS ####
if not sys.argv[2]:
    pass#print  "Here in default-py going in showContent"
    ok = showMainMenu()
else:
    if mode == str(1):
        ok = showLetterList(url)
    elif mode == str(2):
        ok = showTitle(url, letter)
    elif mode == str(3):
        ok = showSeason(name, url, thumbnail, fanart)
    elif mode == str(4):
        ok = showQuality(name, url, thumbnail, fanart)
    elif mode == str(5):
        ok = showVideoList(name, url, thumbnail, fanart)
    elif mode == str(69):
        ok = playVideo(url)
    elif mode == str(99):  #Click Search
        ok = showSearch()
